2. Cómo lograr la persistencia de los datos con Room
3. Cómo leer y actualizar datos con Room 